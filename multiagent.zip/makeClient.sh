#!/bin/bash
java -cp all_v4.4.jar PLH512.client.Client
